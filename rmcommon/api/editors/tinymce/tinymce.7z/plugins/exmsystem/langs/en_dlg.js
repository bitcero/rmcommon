tinyMCE.addI18n('en.exmsystem_dlg',{
exm_more_alt : 'Insert more tag',
exm_page_alt: 'New page',
exm_more_desc: 'Insert the more tag',
// Icons
exm_icons_title : 'Emoticons',
exm_icons_insert : 'Insert Emoticons'
});