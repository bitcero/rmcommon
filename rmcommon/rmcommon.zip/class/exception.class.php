<?php
// $Id$
// --------------------------------------------------------------
// Common Utilities
// A modules framework by Red Mexico
// Author: Eduardo Cortes
// Email: i.bitcero@gmail.com
// License: GPL 2.0
// URI: http://www.redmexico.com.mx
// --------------------------------------------------------------

/**
 * RMException represents a generic exception for all purposes.
 */
class RMException extends Exception
{
}
