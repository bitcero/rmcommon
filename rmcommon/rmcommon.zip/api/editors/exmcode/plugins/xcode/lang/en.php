<?php

define('INPUT','Insert code block here:');
define('INSERT','Insert Code');
define('CANCEL','Cancel');
