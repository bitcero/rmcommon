<?php
define('INPUT','Insert quote here:');
define('INSERT','Insert Quote');
define('CANCEL','Cancel');
