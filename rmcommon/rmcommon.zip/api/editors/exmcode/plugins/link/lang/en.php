<?php

define('TITLE','Link title:');
define('URL','Link URL:');
define('INSERT','Insert');
define('CANCEL','Cancel');
